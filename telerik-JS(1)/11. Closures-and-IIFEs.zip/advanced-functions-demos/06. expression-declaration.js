if(true){
	//var printMsg =
  function printMsg(msg) { 
    console.log("Message (from if): " + msg);
  }
}
else{    
	//var printMsg = 
  function printMsg(msg) {
    console.log("Message (from else): " + msg);
  }
}
printMsg("message");