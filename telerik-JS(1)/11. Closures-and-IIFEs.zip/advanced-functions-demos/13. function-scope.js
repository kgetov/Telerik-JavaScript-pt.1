if(true) 
	(function(){ 
		var result = 5;
	}());
console.log(result);//ReferenceError
